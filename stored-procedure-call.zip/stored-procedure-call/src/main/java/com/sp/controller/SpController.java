package com.sp.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sp.constants.ErrorConst;
import com.sp.exception.InvalidApiKeyException;
import com.sp.exception.InvalidAppKeyException;
import com.sp.service.SpService;

@RestController
@RequestMapping("/sp")
public class SpController {
	
    @Autowired
    SpService spService;
	
//    @GetMapping(value = "/get-student-list-by-department")
//	public ResponseEntity<Object> getStudentListByDepartment(HttpServletRequest request,
//			@RequestHeader("appKey") String appKey, @RequestParam("apiKey") String apiKey,
//			@RequestParam("dept") String dept) {
//		if (apiKey == null) {
//			throw new InvalidApiKeyException(ErrorConst.API_KEY_IS_REQUIRED,
//					"Api Key is required for accessing this Resource");
//		}
//
//		if (apiKey != null && apiKey.equals("XYZ")) {
//			if (appKey != null && !appKey.isEmpty() && "ABC".equals(appKey)) {
//				return new ResponseEntity<>(
//						spService.getStudentListByDepartment(dept),
//						HttpStatus.OK);
//
//			} else {
//				throw new InvalidAppKeyException(ErrorConst.INVALID_APP_KEY, "Invalid APP Key");
//			}
//		} else {
//			throw new InvalidApiKeyException(ErrorConst.INVALID_API_KEY, "Invalid API Key");
//		}
//
//	}
    
    @GetMapping(value = "/get-student-list-by-department")
   	public ResponseEntity<Object> getStudentListByDepartment(@RequestParam("dept") String dept) {

   				return new ResponseEntity<>(
   						spService.getStudentListByDepartment(dept),
   						HttpStatus.OK);

   	}

}
