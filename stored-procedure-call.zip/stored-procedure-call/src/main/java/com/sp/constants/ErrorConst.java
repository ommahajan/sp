package com.sp.constants;

import org.springframework.stereotype.Component;

@Component
public class ErrorConst {
	
	// Invalid Request DATA
	
	public static final String No_DATA_FOUND = "SPERR-001";
	
	public static final String API_KEY_IS_REQUIRED = "SPERR-002";
	
	public static final String PARAM_MISSING = "SPERR-003";
	
	public static final String SERVER_ERROR = "SPERR-004";
	
	public static final String INVALID_APP_KEY = "SPERR-005";
	
	public static final String INVALID_API_KEY = "SPERR-006";

}
