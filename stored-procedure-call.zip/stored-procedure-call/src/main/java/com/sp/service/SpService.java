package com.sp.service;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sp.constants.ErrorConst;
import com.sp.dao.StudentDAO;
import com.sp.dto.StudentDTO;

@Service
public class SpService {
	
    @Autowired
    private StudentDAO studentDAO;
	
    @Transactional
    public Map<String, Object> getStudentListByDepartment(String department) {
    	 Map<String, Object> responseMap = new HashMap<>();
    	 try {
    		 Map<String, Object> outParam = studentDAO.getStudentListByDepartment(department);
     		
             @SuppressWarnings("unchecked")
 			List<StudentDTO> stressList = (List<StudentDTO>) outParam.get("stuentListByDepartmentFromProc");
 			
 			List<StudentDTO> sortededStudentList = new ArrayList<>();
 			if(stressList.size() > 0) {
 				sortededStudentList = stressList.stream().sorted(Comparator.comparing(SpService::comparingByStudentName).thenComparing(SpService::comparingByStudentId)).collect(Collectors.toList());
 			}
 			
 			responseMap.put("stress", sortededStudentList != null ? sortededStudentList : new ArrayList<>());
            responseMap.put("status", true);
            responseMap.put("message", "Student List By Department Delivered Successfully");
            
		} catch (Exception e) {
			e.printStackTrace();
            responseMap.put("status", false);
            responseMap.put("message", "Some error occurred, Please try again !!");
            responseMap.put("errorCode", ErrorConst.No_DATA_FOUND);
		}
    	 return responseMap;
    }
    
    private static String comparingByStudentName(StudentDTO studentDTO){
        return studentDTO.getName();
    }
    
    private static Integer comparingByStudentId(StudentDTO studentDTO){
        return studentDTO.getId();
    }

}
